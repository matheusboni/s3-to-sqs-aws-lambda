# s3-to-sqs-aws-lambda
AWS Lambda that receive a event from s3, process the file and send the content to sqs.
