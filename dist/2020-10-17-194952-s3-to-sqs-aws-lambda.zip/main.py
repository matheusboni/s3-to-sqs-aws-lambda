
def handler(event, _):
    print(event)