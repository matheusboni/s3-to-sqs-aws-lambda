# sqs-to-dynamodb-aws-lambda
AWS Lambda that receive events from sqs, process and send the content to dynamodb.
